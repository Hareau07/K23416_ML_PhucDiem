from numpy import nan as NA
import pandas as pd

data = pd.DataFrame([[1., 6.5, 3.],
                     [2., NA, NA],
                     [NA, NA, NA],
                     [3., 6.5, 3.], # thuật toán fill là lấy trung bình
                     [4., 7.5, 7.],
                     [5, 2.5, 3.],
                     [NA, NA, NA],
                     [6., 3.5, 3.]])
print("Dữ liệu gốc:")
print(data)
print("-" * 20)

# Điền bằng mean
filled_mean = data.fillna(data.mean())
print("Điền bằng mean:")
print(filled_mean)
print("-" * 20)

# Điền bằng median
filled_median = data.fillna(data.median())
print("Điền bằng median:")
print(filled_median)
print("-" * 20)

# Điền bằng mode (lấy mode đầu tiên)
filled_mode = data.fillna(data.mode().iloc[0])
print("Điền bằng mode:")
print(filled_mode)


